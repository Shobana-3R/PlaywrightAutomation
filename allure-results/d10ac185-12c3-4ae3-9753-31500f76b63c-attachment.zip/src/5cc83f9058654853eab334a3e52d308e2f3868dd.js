const {test, expect} = require('@playwright/test')
const {customtest} = require('../utils/test-base')
const {POManager} = require('../POM/POManager')
//JSON -> string ->JS object
const dataset = JSON.parse(JSON.stringify(require("../test-data/placeorder-testdata.json")))
for(const data of dataset)
{

test (`eCommerce E2E for ${data.productName}`, async ({page}) =>
{
    const poManager = new POManager(page)
    
    const loginPage = poManager.getLoginPage()
    await loginPage.goTo()
    await loginPage.validLogin(data.username,data.password)
    const dashboardPage = poManager.getDashboardPage()
    await dashboardPage.searchProductAddCart(data.productName)
    await dashboardPage.navigateToCart()

     
const cartPage = poManager.getCartPage();
    await cartPage.VerifyProductIsDisplayed(data.productName);
    await cartPage.Checkout();

    const ordersReviewPage = poManager.getOrdersReviewPage();
    await ordersReviewPage.searchCountryAndSelect("ind","India");
    const orderId = await ordersReviewPage.SubmitAndGetOrderId();
   console.log(orderId);
   await dashboardPage.navigateToOrders();
   const ordersHistoryPage = poManager.getOrdersHistoryPage();
   await ordersHistoryPage.searchOrderAndSelect(orderId);
   expect(orderId.includes(await ordersHistoryPage.getOrderId())).toBeTruthy();

 });

}

customtest('test with custom test data', async ({page, testDataForOrder}) =>
{
    const poManager = new POManager(page)
    
    const loginPage = poManager.getLoginPage()
    await loginPage.goTo()
    await loginPage.validLogin(testDataForOrder.username,testDataForOrder.password)
    const dashboardPage = poManager.getDashboardPage()
    await dashboardPage.searchProductAddCart(testDataForOrder.productName)
    await dashboardPage.navigateToCart()

     
const cartPage = poManager.getCartPage();
    await cartPage.VerifyProductIsDisplayed(testDataForOrder.productName);
    await cartPage.Checkout();

const ordersReviewPage = poManager.getOrdersReviewPage()
await ordersReviewPage.searchCountryAndSelect("ind", "India")
const orderId = await ordersReviewPage.SubmitAndGetOrderId()
console.log(orderId)
await dashboardPage.navigateToOrders()
const ordersHistoryPage = poManager.getOrdersHistoryPage()
await ordersHistoryPage.searchOrderAndSelect(orderId)
expect(orderId.includes(await ordersHistoryPage.getOrderId())).toBeTruthy()
 });